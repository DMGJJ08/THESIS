"""
feedback_loop.py
Phase 5: Collaborative Filtering with Feedback Loop
- Collects user ratings
- Adjusts weight vector using gradient descent
- Maintains user-item interaction matrix
- Re-evaluates model every 50 interactions
"""

import json
import os
import numpy as np
from knn_ranker import DEFAULT_WEIGHTS


# Persistence file for weights and interaction log
WEIGHTS_FILE = "cf_weights.json"
INTERACTIONS_FILE = "cf_interactions.json"

# Learning rate for gradient descent
ALPHA = 0.05


def load_weights() -> list:
    """Load saved weights or return defaults."""
    if os.path.exists(WEIGHTS_FILE):
        with open(WEIGHTS_FILE, 'r') as f:
            return json.load(f)
    return DEFAULT_WEIGHTS.copy()


def save_weights(weights: list):
    """Persist updated weights."""
    with open(WEIGHTS_FILE, 'w') as f:
        json.dump(weights, f)


def load_interactions() -> list:
    """Load interaction log."""
    if os.path.exists(INTERACTIONS_FILE):
        with open(INTERACTIONS_FILE, 'r') as f:
            return json.load(f)
    return []


def save_interactions(interactions: list):
    """Persist interactions."""
    with open(INTERACTIONS_FILE, 'w') as f:
        json.dump(interactions, f)


def normalize_weights(weights: list) -> list:
    """Normalize weight vector so it sums to 1.0."""
    total = sum(abs(w) for w in weights)
    if total == 0:
        return DEFAULT_WEIGHTS.copy()
    return [w / total for w in weights]


def update_weights(
    recipe: dict,
    rating_actual: float,
    weights: list
) -> list:
    """
    Update weights using gradient descent based on user rating.
    
    Formula:
        error = rating_actual_normalized - predicted_score
        wi_new = wi_old + alpha * error * feature_i
    
    Args:
        recipe: the rated recipe with feature scores attached
        rating_actual: user rating (1-5 scale, normalized to 0-1)
        weights: current weight vector
    
    Returns:
        Updated normalized weight vector
    """
    # Normalize rating from 1-5 to 0-1
    rating_norm = (rating_actual - 1) / 4.0

    # Feature vector for this recipe
    features = [
        recipe.get("_cosine_score", 0.0),
        recipe.get("_nutrition_score", 0.0),
        recipe.get("popularity", 0.0),
        recipe.get("_cf_score", 0.0),
    ]

    # Predicted score
    predicted = sum(w * f for w, f in zip(weights, features))

    # Error
    error = rating_norm - predicted

    print(f"\n[Phase 5 - CF Feedback Loop]")
    print(f"  Recipe: {recipe.get('title')}")
    print(f"  Rating: {rating_actual}/5 (normalized: {rating_norm:.4f})")
    print(f"  Predicted score: {predicted:.4f} | Error: {error:.4f}")

    # Gradient descent weight update
    new_weights = []
    for i, (w, f) in enumerate(zip(weights, features)):
        w_new = w + ALPHA * error * f
        new_weights.append(max(0.01, w_new))  # Prevent negative weights

    # Normalize
    new_weights = normalize_weights(new_weights)

    print(f"  Old weights: {[round(w, 4) for w in weights]}")
    print(f"  New weights: {[round(w, 4) for w in new_weights]}")

    return new_weights


def log_interaction(
    user_id: str,
    recipe_id: int,
    recipe_title: str,
    rating: float,
    interactions: list
) -> list:
    """Add a new user-item interaction to the log."""
    interactions.append({
        "user_id": user_id,
        "recipe_id": recipe_id,
        "recipe_title": recipe_title,
        "rating": rating
    })
    return interactions


def get_cf_score(recipe_id: int, interactions: list, recipe: dict = None) -> float:
    """
    Compute collaborative filtering score for a recipe.
    Falls back to popularity score if no interactions exist (cold start fix).
    Returns normalized score (0.0 to 1.0).
    """
    ratings = [
        i["rating"] for i in interactions
        if i["recipe_id"] == recipe_id
    ]
    if not ratings:
        # Cold start fallback: use popularity as initial CF score
        if recipe:
            return recipe.get("popularity", 0.5)
        return 0.5  # neutral default
    avg = sum(ratings) / len(ratings)
    return (avg - 1) / 4.0  # Normalize 1-5 to 0-1


def apply_cf_scores(candidates: list, interactions: list) -> list:
    """Attach CF scores to all candidates before ranking."""
    for recipe in candidates:
        recipe["_cf_score"] = get_cf_score(recipe["id"], interactions, recipe)
    return candidates


def should_reevaluate(interactions: list) -> bool:
    """Check if model should be re-evaluated (every 50 interactions)."""
    return len(interactions) > 0 and len(interactions) % 50 == 0


def reevaluate_model(interactions: list, weights: list) -> dict:
    """
    Simple model re-evaluation: compute average prediction error
    over all logged interactions.
    
    Returns evaluation summary dict.
    """
    if not interactions:
        return {"message": "No interactions to evaluate"}

    errors = []
    for interaction in interactions:
        rating_norm = (interaction["rating"] - 1) / 4.0
        # Use a neutral predicted score since we don't store feature vectors
        predicted = 0.5
        errors.append(abs(rating_norm - predicted))

    mae = sum(errors) / len(errors)
    return {
        "total_interactions": len(interactions),
        "mean_absolute_error": round(mae, 4),
        "current_weights": weights
    }
