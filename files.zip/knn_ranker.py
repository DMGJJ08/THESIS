"""
knn_ranker.py
Phase 4: KNN-Based Ranking
- Constructs multi-dimensional feature vectors
- Applies weighted composite scoring
- Ranks candidates by KNN distance to ideal profile
"""

import numpy as np
from sklearn.neighbors import NearestNeighbors


# Default weight vector: [cosine, nutrition, popularity, cf_score]
# These are updated by the feedback loop in Phase 5
DEFAULT_WEIGHTS = [0.40, 0.30, 0.15, 0.15]


def build_feature_vectors(candidates: list) -> np.ndarray:
    """
    Build multi-dimensional feature matrix from scored candidates.
    
    Feature vector per recipe: [cosine_score, nutrition_score, popularity, cf_score]
    """
    vectors = []
    for recipe in candidates:
        vec = [
            recipe.get("_cosine_score", 0.0),
            recipe.get("_nutrition_score", 0.0),
            recipe.get("popularity", 0.0),
            recipe.get("_cf_score", 0.0),
        ]
        vectors.append(vec)
    return np.array(vectors)


def compute_composite_scores(feature_matrix: np.ndarray, weights: list) -> np.ndarray:
    """
    Compute weighted composite score for each recipe.
    score(r) = w1*cosine + w2*nutrition + w3*popularity + w4*cf_score
    """
    w = np.array(weights)
    return feature_matrix @ w


def apply_knn_ranking(
    candidates: list,
    weights: list = None,
    k: int = 5,
    top_n: int = 5
) -> list:
    """
    Main KNN ranking phase.
    
    Args:
        candidates: scored recipe candidates from Phase 3
        weights: weight vector [w1, w2, w3, w4]
        k: number of nearest neighbors
        top_n: number of final recommendations to return
    
    Returns:
        Top-N ranked recipes
    """
    if not candidates:
        return []

    if weights is None:
        weights = DEFAULT_WEIGHTS

    print(f"\n[Phase 4 - KNN Ranking]")
    print(f"  Weights: cosine={weights[0]}, nutrition={weights[1]}, popularity={weights[2]}, cf={weights[3]}")
    print(f"  k={k}, returning top-{top_n}")

    # Build feature matrix
    feature_matrix = build_feature_vectors(candidates)

    # Ideal profile: perfect score on all dimensions
    ideal_profile = np.array([[1.0, 1.0, 1.0, 1.0]])

    # Apply KNN to find recipes closest to ideal profile
    k_actual = min(k, len(candidates))
    knn = NearestNeighbors(n_neighbors=k_actual, metric='euclidean')
    knn.fit(feature_matrix)
    distances, indices = knn.kneighbors(ideal_profile)

    # Compute composite scores for all candidates
    composite_scores = compute_composite_scores(feature_matrix, weights)

    # Attach scores to recipes
    for i, recipe in enumerate(candidates):
        recipe["_composite_score"] = float(composite_scores[i])
        recipe["_knn_distance"] = float(np.min(
            np.linalg.norm(feature_matrix[i] - ideal_profile)
        ))

    # Sort by composite score descending
    ranked = sorted(candidates, key=lambda r: r["_composite_score"], reverse=True)

    # Return top-N
    top_results = ranked[:top_n]

    print(f"\n  Top-{top_n} Ranked Results:")
    for rank, recipe in enumerate(top_results, 1):
        print(f"  #{rank} {recipe['title']} | score={recipe['_composite_score']:.4f} | "
              f"cosine={recipe['_cosine_score']:.4f} | nutrition={recipe['_nutrition_score']:.4f}")

    return top_results
