"""
app.py
HCCF-RA Web Interface using Flask
Run: python app.py
Then open: http://localhost:5000
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, request, jsonify, render_template_string
from hccf_ra import HCCFRA

app = Flask(__name__)
engine = HCCFRA()

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>HCCF-RA Recipe Recommender</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    min-height: 100vh;
    color: #eee;
  }

  header {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(255,255,255,0.1);
    padding: 18px 40px;
    display: flex;
    align-items: center;
    gap: 14px;
  }

  header .logo {
    font-size: 28px;
  }

  header h1 {
    font-size: 20px;
    font-weight: 700;
    color: #e94560;
    letter-spacing: 1px;
  }

  header p {
    font-size: 12px;
    color: #aaa;
    margin-top: 2px;
  }

  .badge {
    background: #e94560;
    color: white;
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 20px;
    font-weight: 700;
    letter-spacing: 1px;
    margin-left: 8px;
  }

  .container {
    max-width: 1100px;
    margin: 40px auto;
    padding: 0 20px;
    display: grid;
    grid-template-columns: 380px 1fr;
    gap: 24px;
  }

  .card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
    padding: 24px;
  }

  .card h2 {
    font-size: 15px;
    font-weight: 700;
    color: #e94560;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  label {
    display: block;
    font-size: 12px;
    color: #aaa;
    margin-bottom: 6px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  textarea {
    width: 100%;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 10px;
    padding: 12px;
    color: #eee;
    font-size: 13px;
    resize: vertical;
    min-height: 120px;
    outline: none;
    transition: border 0.2s;
    font-family: inherit;
  }

  textarea:focus {
    border-color: #e94560;
  }

  .health-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 4px;
  }

  .health-option {
    position: relative;
  }

  .health-option input[type="radio"] {
    display: none;
  }

  .health-option label {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 10px 12px;
    cursor: pointer;
    transition: all 0.2s;
    font-size: 13px;
    color: #ccc;
    text-transform: none;
    letter-spacing: 0;
    margin: 0;
  }

  .health-option input[type="radio"]:checked + label {
    background: rgba(233, 69, 96, 0.2);
    border-color: #e94560;
    color: #fff;
  }

  .health-option label:hover {
    border-color: rgba(233,69,96,0.5);
  }

  .health-icon { font-size: 16px; }

  .top-n-row {
    display: flex;
    gap: 8px;
    margin-top: 4px;
  }

  .top-n-row button {
    flex: 1;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 8px;
    padding: 8px;
    color: #ccc;
    cursor: pointer;
    font-size: 13px;
    transition: all 0.2s;
  }

  .top-n-row button.active,
  .top-n-row button:hover {
    background: rgba(233,69,96,0.2);
    border-color: #e94560;
    color: #fff;
  }

  .mb { margin-bottom: 18px; }

  .btn-recommend {
    width: 100%;
    background: linear-gradient(135deg, #e94560, #c23152);
    border: none;
    border-radius: 12px;
    padding: 14px;
    color: white;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    letter-spacing: 1px;
    transition: transform 0.15s, box-shadow 0.15s;
    margin-top: 4px;
  }

  .btn-recommend:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(233,69,96,0.4);
  }

  .btn-recommend:active { transform: translateY(0); }

  .btn-recommend:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }

  /* Results */
  .results-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  }

  .results-count {
    font-size: 12px;
    color: #aaa;
    background: rgba(255,255,255,0.05);
    padding: 4px 12px;
    border-radius: 20px;
  }

  .recipe-card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 14px;
    padding: 18px;
    margin-bottom: 14px;
    transition: border 0.2s, transform 0.2s;
    animation: fadeIn 0.4s ease forwards;
    opacity: 0;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .recipe-card:hover {
    border-color: rgba(233,69,96,0.4);
    transform: translateY(-2px);
  }

  .recipe-rank {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    background: #e94560;
    border-radius: 50%;
    font-size: 13px;
    font-weight: 700;
    margin-right: 10px;
  }

  .recipe-title {
    font-size: 16px;
    font-weight: 700;
    color: #fff;
    display: inline;
  }

  .recipe-category {
    font-size: 11px;
    color: #e94560;
    background: rgba(233,69,96,0.1);
    padding: 2px 8px;
    border-radius: 20px;
    margin-left: 8px;
  }

  .recipe-ingredients {
    font-size: 12px;
    color: #aaa;
    margin: 10px 0 12px;
    line-height: 1.6;
  }

  .recipe-ingredients span {
    display: inline-block;
    background: rgba(255,255,255,0.06);
    border-radius: 6px;
    padding: 2px 8px;
    margin: 2px;
    font-size: 11px;
  }

  .nutrition-row {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 12px;
  }

  .nutrition-pill {
    background: rgba(255,255,255,0.05);
    border-radius: 8px;
    padding: 6px 10px;
    font-size: 11px;
    color: #ccc;
    text-align: center;
  }

  .nutrition-pill strong {
    display: block;
    font-size: 13px;
    color: #fff;
  }

  .scores-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 6px;
  }

  .score-item {
    background: rgba(255,255,255,0.04);
    border-radius: 8px;
    padding: 8px;
    text-align: center;
  }

  .score-item .score-label {
    font-size: 9px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
  }

  .score-bar-bg {
    background: rgba(255,255,255,0.08);
    border-radius: 4px;
    height: 4px;
    margin: 4px 0;
    overflow: hidden;
  }

  .score-bar {
    height: 100%;
    background: #e94560;
    border-radius: 4px;
    transition: width 0.8s ease;
  }

  .score-value {
    font-size: 12px;
    font-weight: 700;
    color: #e94560;
  }

  .composite-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: linear-gradient(135deg, rgba(233,69,96,0.2), rgba(233,69,96,0.05));
    border: 1px solid rgba(233,69,96,0.3);
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 12px;
    color: #e94560;
    font-weight: 700;
    margin-top: 10px;
  }

  /* Rating */
  .rating-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 10px;
  }

  .rating-label {
    font-size: 11px;
    color: #888;
  }

  .stars {
    display: flex;
    gap: 2px;
  }

  .star {
    font-size: 18px;
    cursor: pointer;
    color: #444;
    transition: color 0.15s, transform 0.15s;
  }

  .star:hover, .star.active { color: #f5a623; transform: scale(1.2); }

  .rating-msg {
    font-size: 11px;
    color: #4caf50;
    margin-left: 4px;
  }

  /* Empty / Loading */
  .empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #555;
  }

  .empty-state .icon { font-size: 48px; margin-bottom: 12px; }
  .empty-state p { font-size: 14px; }

  .loading {
    text-align: center;
    padding: 40px;
    color: #888;
    font-size: 14px;
  }

  .error-msg {
    background: rgba(233,69,96,0.1);
    border: 1px solid rgba(233,69,96,0.3);
    border-radius: 10px;
    padding: 16px;
    color: #e94560;
    font-size: 13px;
    text-align: center;
  }

  /* Eval Panel */
  .eval-section {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.08);
  }

  .eval-section h3 {
    font-size: 12px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 12px;
  }

  .eval-metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  .eval-metric {
    background: rgba(255,255,255,0.04);
    border-radius: 10px;
    padding: 12px;
    text-align: center;
  }

  .eval-metric .metric-val {
    font-size: 22px;
    font-weight: 700;
    color: #e94560;
  }

  .eval-metric .metric-name {
    font-size: 10px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 2px;
  }

  @media (max-width: 768px) {
    .container { grid-template-columns: 1fr; }
    .scores-row { grid-template-columns: repeat(2, 1fr); }
  }
</style>
</head>
<body>

<header>
  <div class="logo">🍽️</div>
  <div>
    <h1>HCCF-RA Recipe Recommender <span class="badge">AI</span></h1>
    <p>Hybrid Constraint-Based Collaborative Filtering Algorithm</p>
  </div>
</header>

<div class="container">
  <!-- LEFT: Input Panel -->
  <div>
    <div class="card">
      <h2>🥦 Input</h2>

      <div class="mb">
        <label>Available Ingredients</label>
        <textarea id="ingredients" placeholder="e.g. chicken breast, garlic, lemon, olive oil, pepper&#10;&#10;Separate with commas or new lines"></textarea>
      </div>

      <div class="mb">
        <label>Health Condition</label>
        <div class="health-grid">
          <div class="health-option">
            <input type="radio" name="health" id="h-general" value="GENERAL" checked/>
            <label for="h-general"><span class="health-icon">✅</span> General</label>
          </div>
          <div class="health-option">
            <input type="radio" name="health" id="h-diabetes" value="DIABETES"/>
            <label for="h-diabetes"><span class="health-icon">🩸</span> Diabetes</label>
          </div>
          <div class="health-option">
            <input type="radio" name="health" id="h-hypertension" value="HYPERTENSION"/>
            <label for="h-hypertension"><span class="health-icon">💊</span> Hypertension</label>
          </div>
          <div class="health-option">
            <input type="radio" name="health" id="h-cardio" value="CARDIOVASCULAR"/>
            <label for="h-cardio"><span class="health-icon">❤️</span> Cardiovascular</label>
          </div>
        </div>
      </div>

      <div class="mb">
        <label>Number of Results</label>
        <div class="top-n-row" id="topn-row">
          <button onclick="setTopN(3)" class="active" id="btn-3">Top 3</button>
          <button onclick="setTopN(5)" id="btn-5">Top 5</button>
          <button onclick="setTopN(10)" id="btn-10">Top 10</button>
        </div>
      </div>

      <button class="btn-recommend" onclick="recommend()" id="rec-btn">
        🔍 Get Recommendations
      </button>

      <!-- Evaluation Metrics -->
      <div class="eval-section" id="eval-section" style="display:none">
        <h3>📊 Algorithm Performance</h3>
        <div class="eval-metrics" id="eval-metrics"></div>
      </div>
    </div>
  </div>

  <!-- RIGHT: Results -->
  <div>
    <div class="card" style="min-height: 400px;">
      <div class="results-header">
        <h2>🍳 Recommendations</h2>
        <span class="results-count" id="results-count" style="display:none"></span>
      </div>
      <div id="results-container">
        <div class="empty-state">
          <div class="icon">🥘</div>
          <p>Enter your ingredients and health condition<br/>to get AI-powered recipe recommendations</p>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  let topN = 3;
  let selectedRatings = {};

  function setTopN(n) {
    topN = n;
    document.querySelectorAll('.top-n-row button').forEach(b => b.classList.remove('active'));
    document.getElementById('btn-' + n).classList.add('active');
  }

  async function recommend() {
    const raw = document.getElementById('ingredients').value.trim();
    if (!raw) { alert('Please enter at least one ingredient!'); return; }

    const ingredients = raw.split(/[,\\n]+/).map(s => s.trim()).filter(Boolean);
    const health = document.querySelector('input[name="health"]:checked').value;

    const btn = document.getElementById('rec-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Processing...';

    document.getElementById('results-container').innerHTML = '<div class="loading">🤖 Running HCCF-RA algorithm...</div>';
    document.getElementById('results-count').style.display = 'none';

    try {
      const res = await fetch('/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ingredients, health_condition: health, top_n: topN })
      });
      const data = await res.json();

      if (data.error) {
        document.getElementById('results-container').innerHTML =
          `<div class="error-msg">⚠️ ${data.error}</div>`;
      } else if (data.results.length === 0) {
        document.getElementById('results-container').innerHTML =
          `<div class="error-msg">😕 No recipes found for your ingredients + health condition.<br/>Try adding more ingredients or selecting General.</div>`;
      } else {
        renderResults(data.results, data.metrics);
      }
    } catch(e) {
      document.getElementById('results-container').innerHTML =
        `<div class="error-msg">❌ Server error. Make sure app.py is running.</div>`;
    }

    btn.disabled = false;
    btn.textContent = '🔍 Get Recommendations';
  }

  function renderResults(results, metrics) {
    const count = document.getElementById('results-count');
    count.textContent = `${results.length} recipe${results.length > 1 ? 's' : ''} found`;
    count.style.display = 'inline-block';

    let html = '';
    results.forEach((r, i) => {
      const delay = i * 0.1;
      const ingTags = r.ingredients.map(ing => `<span>${ing}</span>`).join('');
      html += `
      <div class="recipe-card" style="animation-delay:${delay}s">
        <div style="margin-bottom:10px">
          <span class="recipe-rank">${i+1}</span>
          <span class="recipe-title">${r.title}</span>
          <span class="recipe-category">${r.category}</span>
        </div>

        <div class="recipe-ingredients">${ingTags}</div>

        <div class="nutrition-row">
          <div class="nutrition-pill"><strong>${r.nutrition.calories}</strong>kcal</div>
          <div class="nutrition-pill"><strong>${r.nutrition.sodium}mg</strong>Sodium</div>
          <div class="nutrition-pill"><strong>${r.nutrition.sugar}g</strong>Sugar</div>
          <div class="nutrition-pill"><strong>${r.nutrition.fat}g</strong>Fat</div>
          <div class="nutrition-pill"><strong>${r.nutrition.protein}g</strong>Protein</div>
        </div>

        <div class="scores-row">
          ${scoreItem('Cosine', r.scores.cosine)}
          ${scoreItem('Nutrition', r.scores.nutrition)}
          ${scoreItem('Popularity', r.scores.popularity)}
          ${scoreItem('CF Score', r.scores.cf)}
        </div>

        <div class="composite-badge">
          🏆 Composite Score: ${r.scores.composite.toFixed(4)}
        </div>

        <div class="rating-row">
          <span class="rating-label">Rate this:</span>
          <div class="stars" id="stars-${r.id}">
            ${[1,2,3,4,5].map(s =>
              `<span class="star" onclick="rate(${r.id}, ${s}, '${r.title}')" id="star-${r.id}-${s}">★</span>`
            ).join('')}
          </div>
          <span class="rating-msg" id="rating-msg-${r.id}"></span>
        </div>
      </div>`;
    });

    document.getElementById('results-container').innerHTML = html;

    // Show evaluation metrics
    if (metrics) {
      const evalSection = document.getElementById('eval-section');
      evalSection.style.display = 'block';
      document.getElementById('eval-metrics').innerHTML = `
        <div class="eval-metric">
          <div class="metric-val">${(metrics.precision * 100).toFixed(0)}%</div>
          <div class="metric-name">Precision@k</div>
        </div>
        <div class="eval-metric">
          <div class="metric-val">${(metrics.recall * 100).toFixed(0)}%</div>
          <div class="metric-name">Recall@k</div>
        </div>
        <div class="eval-metric">
          <div class="metric-val">${metrics.f1.toFixed(2)}</div>
          <div class="metric-name">F1-Score</div>
        </div>
        <div class="eval-metric">
          <div class="metric-val">${metrics.mrr.toFixed(2)}</div>
          <div class="metric-name">MRR</div>
        </div>
      `;
    }
  }

  function scoreItem(label, val) {
    const pct = Math.round(val * 100);
    return `
      <div class="score-item">
        <div class="score-label">${label}</div>
        <div class="score-bar-bg"><div class="score-bar" style="width:${pct}%"></div></div>
        <div class="score-value">${val.toFixed(3)}</div>
      </div>`;
  }

  async function rate(recipeId, rating, title) {
    // Highlight stars
    for (let s = 1; s <= 5; s++) {
      const star = document.getElementById(`star-${recipeId}-${s}`);
      star.classList.toggle('active', s <= rating);
    }

    await fetch('/rate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipe_id: recipeId, rating, title })
    });

    document.getElementById(`rating-msg-${recipeId}`).textContent = '✓ Rated!';
  }

  // Enter key support
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.key === 'Enter') recommend();
  });
</script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML)


@app.route('/recommend', methods=['POST'])
def recommend():
    try:
        data = request.json
        ingredients = data.get('ingredients', [])
        health_condition = data.get('health_condition', 'GENERAL')
        top_n = int(data.get('top_n', 5))

        if not ingredients:
            return jsonify({'error': 'No ingredients provided'}), 400

        results = engine.recommend(
            user_ingredients=ingredients,
            health_condition=health_condition,
            top_n=top_n
        )

        # Format results for frontend
        formatted = []
        for r in results:
            formatted.append({
                'id': r['id'],
                'title': r['title'],
                'category': r.get('category', 'N/A'),
                'ingredients': r.get('ingredients', []),
                'nutrition': r.get('nutrition', {}),
                'scores': {
                    'cosine': round(r.get('_cosine_score', 0), 4),
                    'nutrition': round(r.get('_nutrition_score', 0), 4),
                    'popularity': round(r.get('popularity', 0), 4),
                    'cf': round(r.get('_cf_score', 0), 4),
                    'composite': round(r.get('_composite_score', 0), 4),
                }
            })

        # Quick evaluation metrics
        from evaluator import precision_at_k, recall_at_k, f1_score, mean_reciprocal_rank
        from preprocessor import preprocess_ingredients
        from evaluator import generate_ground_truth
        from dataset import RECIPES

        user_norm = preprocess_ingredients(ingredients)
        relevant = generate_ground_truth(RECIPES, user_norm, health_condition)
        rec_ids = [r['id'] for r in results]

        p = precision_at_k(rec_ids, relevant, top_n)
        r_score = recall_at_k(rec_ids, relevant, top_n)
        f = f1_score(p, r_score)
        mrr = mean_reciprocal_rank([(rec_ids, relevant)])

        metrics = {
            'precision': round(p, 4),
            'recall': round(r_score, 4),
            'f1': round(f, 4),
            'mrr': round(mrr, 4)
        }

        return jsonify({'results': formatted, 'metrics': metrics})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/rate', methods=['POST'])
def rate():
    try:
        data = request.json
        recipe_id = data.get('recipe_id')
        rating = float(data.get('rating', 3))
        title = data.get('title', '')

        # Find recipe in dataset
        from dataset import RECIPES
        recipe = next((r for r in RECIPES if r['id'] == recipe_id), None)

        if recipe:
            # Add dummy scores if missing
            recipe['_cosine_score'] = recipe.get('_cosine_score', 0.5)
            recipe['_nutrition_score'] = recipe.get('_nutrition_score', 0.5)
            recipe['_cf_score'] = recipe.get('_cf_score', 0.5)
            engine.submit_rating(recipe, rating=rating, user_id='web_user')

        return jsonify({'status': 'ok'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    print("\n" + "="*50)
    print("  HCCF-RA Web App Starting...")
    print("  Open browser: http://localhost:5000")
    print("="*50 + "\n")
    app.run(debug=False, port=5000)
