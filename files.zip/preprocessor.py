"""
preprocessor.py
Phase 1: NLP Preprocessing
- Tokenization
- Lemmatization (rule-based, no NLTK needed)
- Stop word and quantity removal
"""

import re

# Common stop words and quantity words to remove
STOP_WORDS = {
    "a", "an", "the", "of", "with", "and", "or", "in", "to", "for",
    "cup", "cups", "tablespoon", "tablespoons", "tbsp", "tsp", "teaspoon",
    "teaspoons", "gram", "grams", "kg", "pound", "pounds", "lb", "lbs",
    "ounce", "ounces", "oz", "piece", "pieces", "pcs", "pc", "slice",
    "slices", "whole", "large", "medium", "small", "fresh", "dried",
    "chopped", "minced", "sliced", "diced", "cooked", "raw", "frozen"
}

# Simple lemmatization rules (suffix-based)
LEMMA_RULES = [
    (r'tomatoes$', 'tomato'),
    (r'potatoes$', 'potato'),
    (r'onions$', 'onion'),
    (r'carrots$', 'carrot'),
    (r'eggs$', 'egg'),
    (r'garlic cloves?$', 'garlic'),
    (r'chicken breasts?$', 'chicken breast'),
    (r'bell peppers?$', 'bell pepper'),
    (r'ies$', 'y'),   # strawberries -> strawberry
    (r'ves$', 'f'),   # leaves -> leaf
    (r'es$', ''),     # tomatoes -> tomatoe (handled above)
    (r's$', ''),      # general plural
]


def lemmatize(token: str) -> str:
    """Apply simple rule-based lemmatization."""
    token = token.lower().strip()
    for pattern, replacement in LEMMA_RULES:
        result = re.sub(pattern, replacement, token)
        if result != token:
            return result.strip()
    return token


def preprocess_ingredients(raw_ingredients: list) -> set:
    """
    Full NLP preprocessing pipeline for ingredient list.
    
    Args:
        raw_ingredients: list of raw ingredient strings
        e.g. ["2 cups of chicken breast", "3 cloves garlic", "salt"]
    
    Returns:
        Normalized set of ingredient tokens
    """
    normalized = set()

    for ingredient in raw_ingredients:
        # Lowercase
        text = ingredient.lower().strip()

        # Remove numbers and fractions
        text = re.sub(r'\d+[\./]?\d*', '', text)

        # Remove parenthetical notes e.g. (optional)
        text = re.sub(r'\(.*?\)', '', text)

        # Tokenize by space and comma
        tokens = re.split(r'[\s,]+', text)

        # Remove stop words
        tokens = [t for t in tokens if t and t not in STOP_WORDS]

        # Lemmatize and rejoin multi-word ingredients
        cleaned = ' '.join([lemmatize(t) for t in tokens]).strip()

        # Remove leftover punctuation
        cleaned = re.sub(r'[^a-z\s]', '', cleaned).strip()

        if cleaned:
            normalized.add(cleaned)

    return normalized


def preprocess_single(ingredient: str) -> str:
    """Preprocess a single ingredient string."""
    result = preprocess_ingredients([ingredient])
    return list(result)[0] if result else ingredient.lower().strip()
