"""
scorer.py
Phase 3: Feature Extraction and Scoring
- TF-IDF vectorization
- Cosine Similarity computation
- Nutritional Scoring based on health condition
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from dataset import HEALTH_CONSTRAINTS


def compute_cosine_scores(user_ingredients: list, candidates: list) -> list:
    """
    Compute TF-IDF Cosine Similarity between user ingredients and each candidate recipe.
    
    Args:
        user_ingredients: list of normalized user ingredient strings
        candidates: list of filtered recipe dicts
    
    Returns:
        candidates with added '_cosine_score' field
    """
    if not candidates:
        return []

    print(f"\n[Phase 3 - TF-IDF + Cosine Similarity]")

    # Build corpus: each recipe is a "document" of ingredients joined as string
    corpus = []
    for recipe in candidates:
        doc = " ".join(recipe.get("ingredients", []))
        corpus.append(doc)

    # Add user ingredient string as query document
    user_doc = " ".join(user_ingredients)
    all_docs = corpus + [user_doc]

    # Fit TF-IDF on all documents
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_docs)

    # User vector is last row
    user_vector = tfidf_matrix[-1]
    recipe_vectors = tfidf_matrix[:-1]

    # Compute cosine similarity for each candidate
    similarities = cosine_similarity(user_vector, recipe_vectors)[0]

    for i, recipe in enumerate(candidates):
        recipe["_cosine_score"] = float(similarities[i])
        print(f"  {recipe['title']}: cosine={similarities[i]:.4f}")

    return candidates


def compute_nutritional_score(recipe: dict, health_condition: str) -> float:
    """
    Score recipe based on how well it fits the health condition's ideal nutritional profile.
    Returns a score between 0.0 and 1.0.
    
    For GENERAL, score is based on overall nutritional balance.
    """
    nutrition = recipe.get("nutrition", {})
    condition = health_condition.upper()

    if condition == "GENERAL":
        # Score based on balanced nutrition
        score = 1.0
        # Penalize very high sodium
        if nutrition.get("sodium", 0) > 800:
            score -= 0.2
        # Penalize very high sugar
        if nutrition.get("sugar", 0) > 20:
            score -= 0.2
        # Penalize very high fat
        if nutrition.get("fat", 0) > 25:
            score -= 0.2
        return max(0.0, score)

    elif condition == "DIABETES":
        # Lower sugar and carbs = better score
        sugar = nutrition.get("sugar", 0)
        carbs = nutrition.get("carbs", 0)
        sugar_score = max(0, 1 - (sugar / 10))     # ideal <= 10g
        carbs_score = max(0, 1 - (carbs / 45))     # ideal <= 45g
        return round((sugar_score + carbs_score) / 2, 4)

    elif condition == "HYPERTENSION":
        # Lower sodium and fat = better score
        sodium = nutrition.get("sodium", 0)
        fat = nutrition.get("fat", 0)
        sodium_score = max(0, 1 - (sodium / 600))  # ideal <= 600mg
        fat_score = max(0, 1 - (fat / 15))         # ideal <= 15g
        return round((sodium_score + fat_score) / 2, 4)

    elif condition == "CARDIOVASCULAR":
        # Lower saturated fat, cholesterol, sodium = better
        sat_fat = nutrition.get("saturated_fat", 0)
        cholesterol = nutrition.get("cholesterol", 0)
        sodium = nutrition.get("sodium", 0)
        sat_score = max(0, 1 - (sat_fat / 5))
        chol_score = max(0, 1 - (cholesterol / 50))
        sod_score = max(0, 1 - (sodium / 500))
        return round((sat_score + chol_score + sod_score) / 3, 4)

    return 0.5  # Default


def apply_scoring(candidates: list, user_ingredients: list, health_condition: str) -> list:
    """
    Full Phase 3 scoring pipeline.
    
    Returns candidates with cosine and nutritional scores attached.
    """
    # TF-IDF + Cosine Similarity
    candidates = compute_cosine_scores(user_ingredients, candidates)

    # Nutritional scoring
    for recipe in candidates:
        recipe["_nutrition_score"] = compute_nutritional_score(recipe, health_condition)

    return candidates
