"""
hccf_ra.py
HCCF-RA: Hybrid Constraint-Based Collaborative Filtering Recipe Algorithm
Main pipeline that connects all 5 phases.

USAGE:
    python hccf_ra.py

or import and use programmatically:
    from hccf_ra import HCCFRA
    engine = HCCFRA()
    results = engine.recommend(["chicken", "garlic", "lemon"], "HYPERTENSION")
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from preprocessor import preprocess_ingredients
from constraint_filter import apply_constraint_filter
from scorer import apply_scoring
from knn_ranker import apply_knn_ranking
from feedback_loop import (
    load_weights, save_weights, load_interactions, save_interactions,
    update_weights, log_interaction, apply_cf_scores, should_reevaluate, reevaluate_model
)
from dataset import RECIPES


class HCCFRA:
    """
    HCCF-RA: Hybrid Constraint-Based Collaborative Filtering Recipe Algorithm
    
    A 5-phase AI pipeline for personalized, health-aware recipe recommendation.
    """

    def __init__(self):
        self.weights = load_weights()
        self.interactions = load_interactions()
        print("\n" + "="*60)
        print("  HCCF-RA Engine Initialized")
        print(f"  Current weights: {[round(w, 4) for w in self.weights]}")
        print(f"  Logged interactions: {len(self.interactions)}")
        print("="*60)

    def recommend(
        self,
        user_ingredients: list,
        health_condition: str = "GENERAL",
        top_n: int = 5,
        k: int = 5
    ) -> list:
        """
        Full 5-phase recommendation pipeline.
        
        Args:
            user_ingredients: list of ingredient strings
            health_condition: GENERAL | DIABETES | HYPERTENSION | CARDIOVASCULAR
            top_n: number of recipes to return
            k: KNN neighbors
        
        Returns:
            List of top-N recommended recipe dicts
        """
        print(f"\n{'='*60}")
        print(f"  NEW RECOMMENDATION REQUEST")
        print(f"  Ingredients: {user_ingredients}")
        print(f"  Health Condition: {health_condition.upper()}")
        print(f"{'='*60}")

        # ── PHASE 1: NLP Preprocessing ──────────────────────────
        print("\n[Phase 1 - NLP Preprocessing]")
        normalized = preprocess_ingredients(user_ingredients)
        print(f"  Normalized: {normalized}")

        # ── PHASE 2: Constraint Filtering ───────────────────────
        candidates = apply_constraint_filter(
            user_ingredients,
            health_condition,
            dataset=RECIPES
        )

        if not candidates:
            print("\n  No recipes found matching your ingredients and health condition.")
            print("  Try adding more ingredients or selecting GENERAL as health condition.")
            return []

        # ── PHASE 3: Feature Extraction + Scoring ───────────────
        candidates = apply_cf_scores(candidates, self.interactions)
        candidates = apply_scoring(candidates, user_ingredients, health_condition)

        # ── PHASE 4: KNN Ranking ─────────────────────────────────
        results = apply_knn_ranking(
            candidates,
            weights=self.weights,
            k=k,
            top_n=top_n
        )

        return results

    def submit_rating(
        self,
        recipe: dict,
        rating: float,
        user_id: str = "anonymous"
    ):
        """
        Phase 5: Submit user rating and trigger feedback loop update.
        
        Args:
            recipe: the rated recipe dict (must have feature scores from recommend())
            rating: user rating from 1 to 5
            user_id: optional user identifier
        """
        if not 1 <= rating <= 5:
            print("  Rating must be between 1 and 5.")
            return

        # Update weights via gradient descent
        self.weights = update_weights(recipe, rating, self.weights)
        save_weights(self.weights)

        # Log interaction
        self.interactions = log_interaction(
            user_id,
            recipe["id"],
            recipe["title"],
            rating,
            self.interactions
        )
        save_interactions(self.interactions)

        # Re-evaluate every 50 interactions
        if should_reevaluate(self.interactions):
            print("\n  [Model Re-evaluation Triggered]")
            eval_result = reevaluate_model(self.interactions, self.weights)
            print(f"  Evaluation: {eval_result}")

    def display_results(self, results: list):
        """Pretty-print recommendation results."""
        if not results:
            print("\n  No recommendations available.")
            return

        print(f"\n{'='*60}")
        print(f"  TOP {len(results)} RECIPE RECOMMENDATIONS")
        print(f"{'='*60}")

        for rank, recipe in enumerate(results, 1):
            print(f"\n  #{rank} {recipe['title'].upper()}")
            print(f"       Category  : {recipe.get('category', 'N/A')}")
            print(f"       Ingredients: {', '.join(recipe.get('ingredients', []))}")
            print(f"       Calories   : {recipe['nutrition'].get('calories', 'N/A')} kcal")
            print(f"       Sodium     : {recipe['nutrition'].get('sodium', 'N/A')} mg")
            print(f"       Sugar      : {recipe['nutrition'].get('sugar', 'N/A')} g")
            print(f"       ---")
            print(f"       AI Scores:")
            print(f"         Cosine Similarity : {recipe.get('_cosine_score', 0):.4f}")
            print(f"         Nutrition Score   : {recipe.get('_nutrition_score', 0):.4f}")
            print(f"         Popularity        : {recipe.get('popularity', 0):.4f}")
            print(f"         CF Score          : {recipe.get('_cf_score', 0):.4f}")
            print(f"         COMPOSITE SCORE   : {recipe.get('_composite_score', 0):.4f}")

        print(f"\n{'='*60}")


def run_demo():
    """Run a full demonstration of HCCF-RA."""
    engine = HCCFRA()

    # ── DEMO 1: General user ──────────────────────────────────
    print("\n\n>>> DEMO 1: General User (Chicken + Garlic + Lemon)")
    results = engine.recommend(
        user_ingredients=["chicken breast", "garlic", "lemon", "olive oil", "pepper", "salt"],
        health_condition="GENERAL",
        top_n=3
    )
    engine.display_results(results)
    if results:
        engine.submit_rating(results[0], rating=5, user_id="demo_user_1")

    # ── DEMO 2: Diabetic user ─────────────────────────────────
    print("\n\n>>> DEMO 2: Diabetic User")
    results2 = engine.recommend(
        user_ingredients=["chicken breast", "lettuce", "cucumber", "tomato", "lemon", "olive oil", "pepper"],
        health_condition="DIABETES",
        top_n=3
    )
    engine.display_results(results2)

    # ── DEMO 3: Hypertensive user ─────────────────────────────
    print("\n\n>>> DEMO 3: Hypertension User")
    results3 = engine.recommend(
        user_ingredients=["chicken breast", "carrot", "celery", "onion", "garlic", "water", "pepper"],
        health_condition="HYPERTENSION",
        top_n=3
    )
    engine.display_results(results3)

    # ── DEMO 4: Filipino ingredients ─────────────────────────
    print("\n\n>>> DEMO 4: Filipino Ingredients")
    results4 = engine.recommend(
        user_ingredients=["chicken", "garlic", "onion", "ginger", "water", "fish sauce", "chili leaves"],
        health_condition="GENERAL",
        top_n=3
    )
    engine.display_results(results4)

    # ── DEMO 5: Cardiovascular ────────────────────────────────
    print("\n\n>>> DEMO 5: Cardiovascular User")
    results5 = engine.recommend(
        user_ingredients=["tuna", "lettuce", "tomato", "cucumber", "lemon", "olive oil", "pepper"],
        health_condition="CARDIOVASCULAR",
        top_n=3
    )
    engine.display_results(results5)

    # ── EVALUATION ───────────────────────────────────────────
    print("\n\n>>> RUNNING FULL ALGORITHM EVALUATION")
    from evaluator import run_evaluation
    eval_results = run_evaluation(k=5, num_test_queries=5)
    print(f"\nFinal Evaluation Metrics: {eval_results}")


if __name__ == "__main__":
    run_demo()
