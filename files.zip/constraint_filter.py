"""
constraint_filter.py
Phase 2: Constraint Satisfaction Problem (CSP) Filtering
- Strict ingredient subset enforcement
- Health condition constraint propagation (Forward Checking)
"""

from dataset import RECIPES, HEALTH_CONSTRAINTS
from preprocessor import preprocess_ingredients


def health_constraint_check(recipe: dict, health_condition: str) -> bool:
    """
    Forward checking: verify recipe meets all health condition constraints.
    
    Args:
        recipe: recipe dict with nutrition metadata
        health_condition: one of DIABETES, HYPERTENSION, CARDIOVASCULAR, GENERAL
    
    Returns:
        True if recipe passes all constraints, False otherwise
    """
    constraints = HEALTH_CONSTRAINTS.get(health_condition.upper(), {})
    nutrition = recipe.get("nutrition", {})

    if not constraints:
        return True  # GENERAL — no restrictions

    # Check each constraint
    if "sugar_max" in constraints:
        if nutrition.get("sugar", 0) > constraints["sugar_max"]:
            return False

    if "carbs_max" in constraints:
        if nutrition.get("carbs", 0) > constraints["carbs_max"]:
            return False

    if "sodium_max" in constraints:
        if nutrition.get("sodium", 0) > constraints["sodium_max"]:
            return False

    if "fat_max" in constraints:
        if nutrition.get("fat", 0) > constraints["fat_max"]:
            return False

    if "saturated_fat_max" in constraints:
        if nutrition.get("saturated_fat", 0) > constraints["saturated_fat_max"]:
            return False

    if "cholesterol_max" in constraints:
        if nutrition.get("cholesterol", 0) > constraints["cholesterol_max"]:
            return False

    return True


def ingredient_subset_check(recipe: dict, user_ingredients_norm: set, threshold: float = 0.75) -> tuple:
    """
    Check if recipe ingredients are a strict subset of user-provided ingredients.
    Uses fuzzy partial matching for ingredient name flexibility.
    
    Returns:
        (passes: bool, match_ratio: float)
    """
    recipe_ingredients_raw = recipe.get("ingredients", [])
    recipe_ingredients_norm = preprocess_ingredients(recipe_ingredients_raw)

    if not recipe_ingredients_norm:
        return False, 0.0

    # Common pantry staples - always assumed available
    PANTRY_STAPLES = {"salt", "pepper", "oil", "water", "sugar"}

    matched = 0
    for r_ing in recipe_ingredients_norm:
        # Always count pantry staples as matched
        if r_ing in PANTRY_STAPLES:
            matched += 1
            continue
        # Exact match
        if r_ing in user_ingredients_norm:
            matched += 1
            continue
        # Partial/substring match
        found = False
        for u_ing in user_ingredients_norm:
            if r_ing in u_ing or u_ing in r_ing:
                matched += 1
                found = True
                break
        # Token overlap match (e.g. "chicken breast" vs "chicken")
        if not found:
            r_tokens = set(r_ing.split())
            for u_ing in user_ingredients_norm:
                u_tokens = set(u_ing.split())
                if r_tokens & u_tokens:
                    matched += 1
                    found = True
                    break

    match_ratio = matched / len(recipe_ingredients_norm)
    passes = match_ratio >= threshold
    return passes, round(match_ratio, 4)


def apply_constraint_filter(
    user_ingredients: list,
    health_condition: str = "GENERAL",
    dataset: list = None
) -> list:
    """
    Main CSP filtering phase.
    
    Args:
        user_ingredients: raw list of user ingredient strings
        health_condition: health condition string
        dataset: recipe dataset (defaults to RECIPES)
    
    Returns:
        List of candidate recipe dicts that pass all constraints
    """
    if dataset is None:
        dataset = RECIPES

    # Preprocess user ingredients
    user_norm = preprocess_ingredients(user_ingredients)
    print(f"\n[Phase 2 - CSP Filter]")
    print(f"  Normalized user ingredients: {user_norm}")
    print(f"  Health condition: {health_condition.upper()}")
    print(f"  Total recipes in dataset: {len(dataset)}")

    candidates = []

    for recipe in dataset:
        # Step 1: Ingredient subset check
        passes_ingredients, match_ratio = ingredient_subset_check(recipe, user_norm)
        if not passes_ingredients:
            continue

        # Step 2: Health constraint check (Forward Checking)
        passes_health = health_constraint_check(recipe, health_condition)
        if not passes_health:
            continue

        # Attach match ratio for later scoring
        recipe_copy = recipe.copy()
        recipe_copy["_match_ratio"] = match_ratio
        candidates.append(recipe_copy)

    print(f"  Candidates after filtering: {len(candidates)}")
    return candidates
