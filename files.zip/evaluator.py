"""
evaluator.py
Algorithm Evaluation Module
- Precision@k
- Recall@k
- F1-Score
- Mean Reciprocal Rank (MRR)
- 70/30 train-test split simulation
"""

import random
import numpy as np
from dataset import RECIPES
from preprocessor import preprocess_ingredients
from constraint_filter import apply_constraint_filter
from scorer import apply_scoring
from knn_ranker import apply_knn_ranking
from feedback_loop import load_weights


def generate_ground_truth(test_recipes: list, user_ingredients: set, health_condition: str) -> set:
    """
    Generate ground truth: recipes where >= 60% ingredients match AND pass health constraints.
    """
    from constraint_filter import ingredient_subset_check, health_constraint_check
    relevant = set()
    for recipe in test_recipes:
        passes, ratio = ingredient_subset_check(recipe, user_ingredients, threshold=0.60)
        passes_health = health_constraint_check(recipe, health_condition)
        if passes and passes_health:
            relevant.add(recipe["id"])
    return relevant


def precision_at_k(recommended_ids: list, relevant_ids: set, k: int) -> float:
    """Precision@k = relevant retrieved in top-k / k"""
    top_k = recommended_ids[:k]
    hits = sum(1 for r_id in top_k if r_id in relevant_ids)
    return hits / k if k > 0 else 0.0


def recall_at_k(recommended_ids: list, relevant_ids: set, k: int) -> float:
    """Recall@k = relevant retrieved in top-k / total relevant"""
    top_k = recommended_ids[:k]
    hits = sum(1 for r_id in top_k if r_id in relevant_ids)
    return hits / len(relevant_ids) if relevant_ids else 0.0


def f1_score(precision: float, recall: float) -> float:
    """F1 = 2 * P * R / (P + R)"""
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def mean_reciprocal_rank(queries_results: list) -> float:
    """
    MRR = (1/|Q|) * sum(1/rank_i)
    queries_results: list of (recommended_ids, relevant_ids) tuples
    """
    reciprocal_ranks = []
    for recommended_ids, relevant_ids in queries_results:
        rr = 0.0
        for rank, r_id in enumerate(recommended_ids, 1):
            if r_id in relevant_ids:
                rr = 1.0 / rank
                break
        reciprocal_ranks.append(rr)
    return sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0.0


def run_evaluation(k: int = 5, num_test_queries: int = 5) -> dict:
    """
    Run full algorithm evaluation using simulated test queries.
    
    Simulates 70/30 train-test split by using 70% of recipes for training
    and evaluating on diverse test user queries.
    """
    print("\n" + "="*60)
    print("HCCF-RA ALGORITHM EVALUATION")
    print("="*60)

    # 70/30 split
    all_recipes = RECIPES.copy()
    random.seed(42)
    random.shuffle(all_recipes)
    split_idx = int(len(all_recipes) * 0.7)
    train_recipes = all_recipes[:split_idx]
    test_recipes = all_recipes[split_idx:]

    print(f"Dataset: {len(all_recipes)} recipes")
    print(f"Training set: {len(train_recipes)} recipes (70%)")
    print(f"Test set: {len(test_recipes)} recipes (30%)")

    # Define test queries (simulated user sessions)
    test_queries = [
        {
            "user_id": "test_user_1",
            "ingredients": ["chicken breast", "garlic", "lemon", "olive oil", "pepper"],
            "health_condition": "GENERAL"
        },
        {
            "user_id": "test_user_2",
            "ingredients": ["egg", "tomato", "onion", "salt", "pepper", "olive oil"],
            "health_condition": "DIABETES"
        },
        {
            "user_id": "test_user_3",
            "ingredients": ["broccoli", "garlic", "onion", "olive oil", "salt", "lemon"],
            "health_condition": "HYPERTENSION"
        },
        {
            "user_id": "test_user_4",
            "ingredients": ["fish fillet", "lemon", "garlic", "pepper", "olive oil", "parsley"],
            "health_condition": "CARDIOVASCULAR"
        },
        {
            "user_id": "test_user_5",
            "ingredients": ["chicken", "garlic", "onion", "ginger", "water", "fish sauce", "chili leaves"],
            "health_condition": "GENERAL"
        },
    ]

    weights = load_weights()
    queries_results = []
    precision_scores = []
    recall_scores = []
    f1_scores = []

    for i, query in enumerate(test_queries[:num_test_queries]):
        print(f"\n--- Test Query {i+1}: {query['user_id']} | {query['health_condition']} ---")

        # Run full pipeline
        candidates = apply_constraint_filter(
            query["ingredients"],
            query["health_condition"],
            dataset=all_recipes  # Use full dataset for evaluation
        )

        if not candidates:
            print("  No candidates found for this query.")
            continue

        scored = apply_scoring(candidates, query["ingredients"], query["health_condition"])
        ranked = apply_knn_ranking(scored, weights=weights, k=5, top_n=k)

        recommended_ids = [r["id"] for r in ranked]

        # Ground truth
        user_norm = preprocess_ingredients(query["ingredients"])
        relevant_ids = generate_ground_truth(all_recipes, user_norm, query["health_condition"])

        print(f"  Recommended IDs: {recommended_ids}")
        print(f"  Relevant IDs:    {list(relevant_ids)}")

        queries_results.append((recommended_ids, relevant_ids))

        p = precision_at_k(recommended_ids, relevant_ids, k)
        r = recall_at_k(recommended_ids, relevant_ids, k)
        f = f1_score(p, r)

        precision_scores.append(p)
        recall_scores.append(r)
        f1_scores.append(f)

        print(f"  Precision@{k}: {p:.4f} | Recall@{k}: {r:.4f} | F1: {f:.4f}")

    # Aggregate metrics
    avg_precision = np.mean(precision_scores) if precision_scores else 0.0
    avg_recall = np.mean(recall_scores) if recall_scores else 0.0
    avg_f1 = np.mean(f1_scores) if f1_scores else 0.0
    mrr = mean_reciprocal_rank(queries_results)

    print("\n" + "="*60)
    print("EVALUATION SUMMARY")
    print("="*60)
    print(f"  Average Precision@{k}: {avg_precision:.4f}")
    print(f"  Average Recall@{k}:    {avg_recall:.4f}")
    print(f"  Average F1-Score:      {avg_f1:.4f}")
    print(f"  Mean Reciprocal Rank:  {mrr:.4f}")
    print("="*60)

    return {
        "precision_at_k": round(avg_precision, 4),
        "recall_at_k": round(avg_recall, 4),
        "f1_score": round(avg_f1, 4),
        "mrr": round(mrr, 4),
        "k": k,
        "num_queries": len(queries_results)
    }
